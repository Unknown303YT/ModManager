package com.riverstone.unknown303.modmanager.global;

import com.riverstone.unknown303.modmanager.data.DataBuilder;
import com.riverstone.unknown303.modmanager.data.Database;

import java.util.Map;

public class Users {
    public static final DataBuilder<User> USER_BUILDER =
            DataBuilder.builder(User.class).encoder(
                    (user, networker) -> {
                        networker.writeUTF(user.getUsername());
                        networker.writeBoolean(user.isServerSide());
                        networker.writeUTF(user.getToken());
                        if (user.isServerSide()) {
                            networker.writeUTF(user.getHash());
                            networker.writeUTF(user.getSalt());
                        }
                    }
            ).decoder(networker -> {
                String username = networker.readUTF();
                boolean isServerSide = networker.readBoolean();
                String token = networker.readUTF();
                String hash = "";
                String salt = "";
                if (isServerSide) {
                    hash = networker.readUTF();
                    salt = networker.readUTF();
                }

                return new User(username, hash, salt, token, isServerSide);
            });

    public static final DataBuilder<Map.Entry<Identifier, User>> USER_DATABASE_BUILDER =
            DataBuilder.toDatabaseBuilder(USER_BUILDER);

    public static final Database<Map.Entry<Identifier, User>> USERS =
            new Database<>(USER_DATABASE_BUILDER);

    public static final User SYSTEM = new User(
            "system", "", "", "", true);
}
