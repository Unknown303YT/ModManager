package com.riverstone.unknown303.modmanager.networking;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.riverstone.unknown303.modmanager.global.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class FriendlyNetworker {
    private final JsonArray data;
    private int count = 0;

    public static FriendlyNetworker writer() {
        return new FriendlyNetworker(new JsonArray());
    }

    public static FriendlyNetworker reader(JsonObject json) {
        return new FriendlyNetworker(json.get("data").getAsJsonArray());
    }

    public static FriendlyNetworker reader(JsonArray data) {
        return new FriendlyNetworker(data);
    }

    private FriendlyNetworker(JsonArray data) {
        this.data = data;
    }

    public FriendlyNetworker writeByte(int b) {
        data.add(b);
        return this;
    }

    public byte readByte() {
        byte b = data.get(count).getAsByte();
        count++;
        return b;
    }

    public FriendlyNetworker writeBoolean(boolean b) {
        data.add(b);
        return this;
    }

    public boolean readBoolean() {
        boolean b = data.get(count).getAsBoolean();
        count++;
        return b;
    }

    public FriendlyNetworker writeInt(int i) {
        return writeByte(i);
    }

    public int readInt() {
        int i = data.get(count).getAsInt();
        count++;
        return i;
    }

    public FriendlyNetworker writeLong(long l) {
        data.add(l);
        return this;
    }

    public long readLong() {
        long l = data.get(count).getAsLong();
        count++;
        return l;
    }

    public FriendlyNetworker writeShort(short s) {
        data.add(s);
        return this;
    }

    public short readShort() {
        short s = data.get(count).getAsShort();
        count++;
        return s;
    }

    public FriendlyNetworker writeDouble(double d) {
        data.add(d);
        return this;
    }

    public double readDouble() {
        double d = data.get(count).getAsDouble();
        count++;
        return d;
    }

    public FriendlyNetworker writeFloat(float f) {
        data.add(f);
        return this;
    }

    public float readFloat() {
        float f = data.get(count).getAsFloat();
        count++;
        return f;
    }

    public FriendlyNetworker writeChar(char c) {
        data.add(c);
        return this;
    }

    public char readChar() {
        String s = readUTF();
        if (s.length() > 1) {
            IllegalStateException exception = new IllegalStateException(
                    new JsonSyntaxException("Tried to read char but string was " +
                            "multiple characters! String: " + s));
            Logger.getLogger().fatal(exception);
            throw new RuntimeException(exception);
        }

        return s.charAt(0);
    }

    public FriendlyNetworker writeJson(JsonElement jsonData) {
        data.add(jsonData.deepCopy());
        return this;
    }

    public JsonElement readJson() {
        JsonElement jsonData = data.get(count);
        count++;
        return jsonData;
    }

    public FriendlyNetworker writeBytes(byte[] bytes) {
        writeInt(bytes.length);
        JsonArray array = new JsonArray();
        for (byte b : bytes) {
            array.add(b);
        }

        return writeJson(array);
    }

    public byte[] readBytes() {
        byte[] bytes = new byte[readInt()];
        JsonArray jsonArray = readJson().getAsJsonArray();
        for (int i = 0; i < jsonArray.size(); i++) {
            bytes[i] = jsonArray.get(i).getAsByte();
        }

        return bytes;
    }

    public FriendlyNetworker writeUTF(String string) {
        data.add(string);
        return this;
    }

    public FriendlyNetworker writeUTF(Object object) {
        return writeUTF(object.toString());
    }

    public String readUTF() {
        return readJson().getAsString();
    }

    public <T> FriendlyNetworker writeList(List<T> list,
                                           Function<T, JsonElement> serialize) {
        JsonArray array = new JsonArray();
        for (T value : list)
            array.add(serialize.apply(value));

        return writeJson(array);
    }

    public <T> List<T> readList(Function<JsonElement, T> deserialize) {
        List<T> list = new ArrayList<>();
        JsonArray jsonArray = readJson().getAsJsonArray();
        for (JsonElement data : jsonArray)
            list.add(deserialize.apply(data));

        return list;
    }

    public <T> FriendlyNetworker writeObject(T value,
                                             Function<T, JsonElement> serialize) {
        return writeJson(serialize.apply(value));
    }

    public <T> T readObject(Function<JsonElement, T> deserialize) {
        return deserialize.apply(readJson());
    }

    public FriendlyNetworker writeNetworker(FriendlyNetworker networker) {
        return writeJson(networker.encode());
    }

    public FriendlyNetworker readNetworker() {
        return reader(readJson().getAsJsonObject());
    }

    public JsonObject encode(JsonObject jsonObject) {
        JsonObject json = jsonObject.deepCopy();
        json.add("data", data);
        return json;
    }

    public JsonObject encode() {
        return encode(new JsonObject());
    }
}
