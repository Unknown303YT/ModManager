package com.riverstone.unknown303.modmanager.feature;

public class AbstractFeatureType<T extends AbstractModFeature> {

}
