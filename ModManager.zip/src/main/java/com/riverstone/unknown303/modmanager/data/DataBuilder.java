package com.riverstone.unknown303.modmanager.data;

import com.riverstone.unknown303.modmanager.feature.AbstractFeatureType;
import com.riverstone.unknown303.modmanager.global.Identifier;
import com.riverstone.unknown303.modmanager.global.Util;
import com.riverstone.unknown303.modmanager.networking.FriendlyNetworker;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class DataBuilder<DATA> {
    public static final Map<Identifier, DataBuilder<?>> BUILDERS =
            new HashMap<>();

    public static <DATA> DataBuilder<DATA> register(Identifier id,
                                                    DataBuilder<DATA> builder) {
        BUILDERS.put(id, builder);
        return builder;
    }

    public static <DATA> DataBuilder<DATA> builder(
            Class<? super DATA> dataType) {
        return new DataBuilder<>(dataType);
    }

    public static <DATA> DataBuilder<Map.Entry<Identifier, DATA>> toDatabaseBuilder(
            DataBuilder<DATA> valueBuilder) {
        DataBuilder<Map.Entry<Identifier, DATA>> builder =
                DataBuilder.builder(Map.Entry.class);
        builder.encoder((entry, networker) -> {
            FriendlyNetworker valueNetworker = FriendlyNetworker.writer();
            valueNetworker.writeUTF(entry.getKey());
            valueNetworker.writeNetworker(valueBuilder.build(entry.getValue()));
            networker.writeNetworker(valueNetworker);
        });
        builder.decoder(networker -> {
            FriendlyNetworker valueNetworker = networker.readNetworker();
            Identifier id = Identifier.parse(valueNetworker.readUTF());
            FriendlyNetworker valueData = valueNetworker.readNetworker();
            return Map.entry(id, valueBuilder.build(valueData));
        });
        return builder;
    }

    private BiConsumer<DATA, FriendlyNetworker> encoder;
    private Function<FriendlyNetworker, DATA> decoder;

    public DataBuilder(Class<? super DATA> packetType) {}

    public DataBuilder<DATA> encoder(BiConsumer<DATA, FriendlyNetworker> encoder) {
        this.encoder = encoder;
        return this;
    }

    public DataBuilder<DATA> decoder(Function<FriendlyNetworker, DATA> decoder) {
        this.decoder = decoder;
        return this;
    }

    public FriendlyNetworker build(DATA data) {
        FriendlyNetworker networker = FriendlyNetworker.writer();
        encoder.accept(data, networker);
        return networker;
    }

    public DATA build(FriendlyNetworker networker) {
        return decoder.apply(networker);
    }

    public Identifier getId() {
        return Util.invertMap(BUILDERS).get(this);
    }
}
